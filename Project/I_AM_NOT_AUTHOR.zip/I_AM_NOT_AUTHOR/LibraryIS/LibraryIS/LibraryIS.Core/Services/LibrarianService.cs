﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class LibrarianService : BaseService<Librarian>
    {
        public LibrarianService(IRepository<Librarian> repository) : base(repository)
        {
        }
    }
}
