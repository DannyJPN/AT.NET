using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using LibraryIS.Core.Services;
using LibraryIS.Infrastructure;
using LibraryIS.Infrastructure.Repositories;
using SimpleInjector;
using System;
using System.Configuration;
using System.Windows.Forms;

namespace LibraryIS.DesktopApp
{
    public static class Program
    {
        private static Container container;

        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Bootstrap();
            Application.Run(new Form1());
        }

        private static void Bootstrap()
        {
            container = new Container();

            string connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            container.RegisterInstance(new Database(connectionString));

            container.Register<IRepository<AccessToken>, AccessTokenRepository>();
            container.Register<IRepository<Author>, AuthorRepository>();
            container.Register<IRepository<Book>, BookRepository>();
            container.Register<IRepository<BookAuthor>, BookAuthorRepository>();
            container.Register<IRepository<Genre>, GenreRepository>();
            container.Register<IRepository<Librarian>, LibrarianRepository>();
            container.Register<IRepository<Reader>, ReaderRepository>();
            container.Register<IRepository<Rent>, RentRepository>();
            container.Register<IRepository<Reservation>, ReservationRepository>();

            container.Register<AccessTokenService>();
            container.Register<AuthorService>();
            container.Register<BookService>();
            container.Register<GenreService>();
            container.Register<LibrarianService>();
            container.Register<ReaderService>();
            container.Register<RentService>();
            container.Register<ReservationService>();
            /*
            container.Register<IUserRepository, SqlUserRepository>(Lifestyle.Singleton);
            container.Register<IUserContext, WinFormsUserContext>();
            container.Register<Form1>();
            */
        }
    }
}
