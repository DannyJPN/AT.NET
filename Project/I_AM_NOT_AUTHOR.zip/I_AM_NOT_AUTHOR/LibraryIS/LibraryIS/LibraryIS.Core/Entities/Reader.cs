﻿using System;
using System.Collections.Generic;

namespace LibraryIS.Core.Entities
{
    public class Reader : Person
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public DateTime RegistrationDate { get; set; }
        public int IdentificationDocumentNumber { get; set; }
        public bool IsStudent { get; set; } = false;
        public string Email { get; set; }
        public int PhoneNumber { get; set; }

        [Exclude]
        public List<Reservation> Reservations => LazyReservations.Value;

        [Exclude]
        public Lazy<List<Reservation>> LazyReservations { private get; set; } = new Lazy<List<Reservation>>(() => throw new NotImplementedException());

        [Exclude]
        public List<Rent> Rents => LazyRents.Value;

        [Exclude]
        public Lazy<List<Rent>> LazyRents { private get; set; } = new Lazy<List<Rent>>(() => throw new NotImplementedException());

        [Exclude]
        public AccessToken AccessToken => LazyAccessToken.Value;

        [Exclude]
        public Lazy<AccessToken> LazyAccessToken { private get; set; } = new Lazy<AccessToken>(() => throw new NotImplementedException());
    }
}
