﻿using LibraryIS.Infrastructure;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using LibraryIS.Core.Services;
using LibraryIS.Infrastructure.Repositories;
using Unity;
using Unity.Injection;

namespace LibraryIS.Wpf
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static readonly IUnityContainer Container = new UnityContainer();

        protected override void OnStartup(StartupEventArgs e)
        {
            Container.RegisterInstance(new Database("server=localhost;database=LibraryIS;Trusted_Connection=True;"));

            Container.RegisterType<IRepository<AccessToken>, AccessTokenRepository>();
            Container.RegisterType<IRepository<Author>, AuthorRepository>();
            Container.RegisterType<IRepository<Book>, BookRepository>();
            Container.RegisterType<IRepository<BookAuthor>, BookAuthorRepository>();
            Container.RegisterType<IRepository<Genre>, GenreRepository>();
            Container.RegisterType<IRepository<Librarian>, LibrarianRepository>();
            Container.RegisterType<IRepository<Reader>, ReaderRepository>();
            Container.RegisterType<IRepository<Rent>, RentRepository>();
            Container.RegisterType<IRepository<Reservation>, ReservationRepository>();

            Container.RegisterType<AccessTokenService>();
            Container.RegisterType<AuthorService>();
            Container.RegisterType<BookService>();
            Container.RegisterType<GenreService>();
            Container.RegisterType<LibrarianService>();
            Container.RegisterType<ReaderService>();
            Container.RegisterType<RentService>();
            Container.RegisterType<ReservationService>();

            Container.RegisterInstance(new ApplicationState());

            /*
            MainWindow mainWindow = Container.Resolve<MainWindow>();
            mainWindow.Show();
            */
        }
    }
}
