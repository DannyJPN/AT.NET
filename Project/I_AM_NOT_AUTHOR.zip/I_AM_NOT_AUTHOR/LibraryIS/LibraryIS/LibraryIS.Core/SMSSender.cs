﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core
{
    public class SMSSender : INotificationCommand
    {
        public int PhoneNumber { get; set; }
        public string Text { get; set; }

        public SMSSender(int phoneNumber, string text)
        {
            PhoneNumber = phoneNumber;
            Text = text;
        }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }
}
