﻿using System;

namespace LibraryIS.Core
{
    public class Class1
    {
    }
}
