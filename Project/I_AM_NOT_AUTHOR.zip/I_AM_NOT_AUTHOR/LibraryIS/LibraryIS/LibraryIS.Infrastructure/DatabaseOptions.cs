﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Infrastructure
{
    public class DatabaseOptions
    {
        public string ConnectionString { get; set; }
    }
}
