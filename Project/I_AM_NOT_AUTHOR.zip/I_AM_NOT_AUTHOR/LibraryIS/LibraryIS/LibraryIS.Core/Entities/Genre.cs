﻿namespace LibraryIS.Core.Entities
{
    public class Genre : BaseEntity
    {
        public string Name { get; set; }
    }
}
