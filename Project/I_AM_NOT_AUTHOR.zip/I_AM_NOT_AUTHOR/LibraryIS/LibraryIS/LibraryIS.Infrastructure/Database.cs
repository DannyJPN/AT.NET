﻿using Microsoft.Extensions.Options;
using System;
using System.Data.SqlClient;

namespace LibraryIS.Infrastructure
{
    public class Database : IDisposable
    {
        private SqlConnection Connection { get; set; }
        private SqlTransaction SqlTransaction { get; set; }
        private string connectionString { get; set; }

        public Database(string connectionString)
        {
            this.connectionString = connectionString;
            Connection = new SqlConnection();
        }

        public Database(IOptions<DatabaseOptions> connectionStringOption)
        {
            connectionString = connectionStringOption.Value.ConnectionString;
            Connection = new SqlConnection();
        }

        public bool Connect()
        {
            if (Connection.State != System.Data.ConnectionState.Open)
            {
                Connection.ConnectionString = connectionString;
                Connection.Open();
            }
            return true;
        }

        public void CloseConnection()
        {
            Connection.Close();
        }

        public int ExecuteNonQuery(SqlCommand command)
        {
            int rowNumber = 0;
            try
            {
                rowNumber = command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                throw e;
            }
            return rowNumber;
        }

        public SqlCommand CreateCommand(string strCommand)
        {
            SqlCommand command = new SqlCommand(strCommand, Connection);

            if (SqlTransaction != null)
            {
                command.Transaction = SqlTransaction;
            }
            return command;
        }

        public SqlDataReader Select(SqlCommand command)
        {
            SqlDataReader sqlReader = command.ExecuteReader();
            return sqlReader;
        }

        public void Dispose()
        {
            Connection.Dispose();
        }
    }
}
