﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;

namespace LibraryIS.Core.Models
{
    public class BookFilter
    {
        public string ISBN { get; set; }
        public string Name { get; set; }
        public string AuthorName { get; set; }
        public List<int> GenresIds { get; set; }
    }
}
