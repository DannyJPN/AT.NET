﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Wpf
{
    public class ApplicationState
    {
        public int? SelectedLibrarianId { get; set; } = 1;
    }
}
