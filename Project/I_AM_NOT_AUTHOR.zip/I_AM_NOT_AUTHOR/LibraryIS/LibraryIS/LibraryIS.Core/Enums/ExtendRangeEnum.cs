﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Core.Enums
{
    public enum ExtendRangeEnum
    {
        D4, W1, W2, M1
    }
}
