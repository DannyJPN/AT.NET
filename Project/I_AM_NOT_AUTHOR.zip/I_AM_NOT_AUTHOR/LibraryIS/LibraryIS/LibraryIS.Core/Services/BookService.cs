﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using LibraryIS.Core.Models;

namespace LibraryIS.Core.Services
{
    public class BookService : BaseService<Book>
    {
        private readonly IRepository<Reservation> _reservationRepository;
        private readonly IRepository<Author> _authorRepository;
        private readonly IRepository<BookAuthor> _bookAuthorRepository;
        private readonly IRepository<Librarian> _librarianRepository;
        private readonly IRepository<Genre> _genreRepository;

        public BookService(
            IRepository<Book> repository, 
            IRepository<Reservation> reservationRepository,
            IRepository<Author> authorRepository,
            IRepository<BookAuthor> bookAuthorRepository,
            IRepository<Librarian> librarianRepository,
            IRepository<Genre> genreRepository
        ) : base(repository)
        {
            _reservationRepository = reservationRepository;
            _authorRepository = authorRepository;
            _bookAuthorRepository = bookAuthorRepository;
            _librarianRepository = librarianRepository;
            _genreRepository = genreRepository;
        }

        public override Book GetById(int id)
        {
            Book book = base.GetById(id);
            book.LazyAuthors = new Lazy<List<Author>>(() =>
            {
                List<int> authorForBookIds = _bookAuthorRepository
                    .GetAll()
                    .Where(ab => ab.BookId == id)
                    .Select(ab => ab.AuthorId)
                    .ToList();

                return _authorRepository
                    .GetAll()
                    .Where(a => authorForBookIds.Contains(a.Id))
                    .ToList();
            });

            book.LazyGenre = new Lazy<Genre>(() =>
            {
                return _genreRepository
                    .GetAll()
                    .FirstOrDefault(g => g.Id == book.GenreId);
            });

            return book;
        }

        public override List<Book> GetAll()
        {
            List<Book> books = base.GetAll();
            books.ForEach(book =>
            {
                book.LazyAuthors = new Lazy<List<Author>>(() =>
                {
                    List<int> authorForBookIds = _bookAuthorRepository
                        .GetAll()
                        .Where(ab => ab.BookId == book.Id)
                        .Select(ab => ab.AuthorId)
                        .ToList();

                    return _authorRepository
                        .GetAll()
                        .Where(a => authorForBookIds.Contains(a.Id))
                        .ToList();
                });

                book.LazyGenre = new Lazy<Genre>(() =>
                {
                    return _genreRepository
                        .GetAll()
                        .FirstOrDefault(g => g.Id == book.GenreId);
                });
            });

            return books;
        }

        public bool CanReserve(int bookId, DateTime from, DateTime to)
        {
            return GetReservations(bookId, from, to).Count == 0;
        }

        public List<Reservation> GetReservations(int bookId)
        {
            return _reservationRepository
                .GetAll()
                .Where(r => r.BookId == bookId)
                .OrderBy(r => r.ReservationDate)
                .ToList();
        }

        public List<Reservation> GetReservations(int bookId, DateTime from, DateTime to)
        {
            return _reservationRepository
                .GetAll()
                .Where(r => r.BookId == bookId && r.ReservationDate >= from && r.ReservationDate <= to)
                .ToList();
        }

        public List<Book> Filter(BookFilter filter)
        {
            IEnumerable<Book> filteredBooks = GetAll();
            if(filter.ISBN != null)
            {
                filteredBooks = filteredBooks.Where(b => b.ISBN.ToLower().Contains(filter.ISBN.ToLower()));
            }

            if (filter.Name != null)
            {
                filteredBooks = filteredBooks.Where(b => b.Name.ToLower().Contains(filter.Name.ToLower()));
            }

            if (filter.AuthorName != null)
            {
                filteredBooks = filteredBooks.Where(b => b.Authors
                                                .Select(a => a.Name.ToLower())
                                                .Any(a => a.Contains(filter.AuthorName)));
            }

            if (filter.GenresIds != null)
            {
                filteredBooks = filteredBooks.Where(b => filter.GenresIds.Contains(b.Genre.Id));
            }

            return filteredBooks.ToList();
        }
    }
}
