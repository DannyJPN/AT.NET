﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Core.Interfaces
{
    public interface INotificationCommand
    {
        void Execute();
    }
}
