﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using LibraryIS.WebApp.Models;
using LibraryIS.Core.Services;
using LibraryIS.Core.Entities;
using LibraryIS.Infrastructure.Repositories;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace LibraryIS.WebApp.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ReaderService _readerService;

        public HomeController(
            ILogger<HomeController> logger,
            ReaderService readerService
        )
        {
            _logger = logger;
            _readerService = readerService;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Login([FromForm] LoginForm loginForm)
        {
            AccessToken accessToken = _readerService.Login(loginForm.Login, loginForm.Password);
            if (accessToken != null)
            {
                var claims = new List<Claim>
                {
                    new Claim("ReaderId", _readerService.GetAll().First(r => r.Login.ToLower() == loginForm.Login.ToLower()).Id.ToString()),
                    new Claim("Token", accessToken.Token)
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(claimsIdentity));
                return Redirect("/");
            }

            ViewBag.UnsuccessfulLogin = true;
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Logout()
        {
            try
            {
                int readerId = int.Parse(HttpContext.User.Claims.First(c => c.Type == "ReaderId").Value);
                _readerService.Logout(readerId);
            }
            catch (Exception)
            {
                await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
                return Redirect("/");
            }

            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Redirect("/");
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
