﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryIS.WebApp
{
    public class DateValidationAttribute : ValidationAttribute
    {
        CultureInfo usCultureInfo = new CultureInfo("en-US", false);

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            string dateString = (string)value;

            try
            {
                DateTime.ParseExact(dateString, "d", usCultureInfo);
            }
            catch (Exception)
            {
                return new ValidationResult(FormatErrorMessage("Wrong date format"));
            }

            return null;
        }
    }
}
