﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class BookRepository : BaseRepository<Book>
    {
        public BookRepository(Database database) : base(database)
        {
        }
    }
}
