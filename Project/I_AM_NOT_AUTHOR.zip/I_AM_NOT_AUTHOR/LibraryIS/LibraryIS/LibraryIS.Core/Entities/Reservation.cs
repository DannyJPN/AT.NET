﻿using System;

namespace LibraryIS.Core.Entities
{
    public class Reservation : BaseEntity
    {
        public int ReaderId { get; set; }
        public int BookId { get; set; }
        public DateTime? ReservationDate { get; set; }
        public string Note { get; set; }

        [Exclude]
        public Book Book => LazyBook.Value;

        [Exclude]
        public Lazy<Book> LazyBook { private get; set; } = new Lazy<Book>(() => throw new NotImplementedException());

        [Exclude]
        public Reader Reader => LazyReader.Value;

        [Exclude]
        public Lazy<Reader> LazyReader { private get; set; } = new Lazy<Reader>(() => throw new NotImplementedException());
    }
}
