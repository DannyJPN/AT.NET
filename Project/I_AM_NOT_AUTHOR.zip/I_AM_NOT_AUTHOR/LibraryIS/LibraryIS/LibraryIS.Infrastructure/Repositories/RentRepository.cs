﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class RentRepository : BaseRepository<Rent>
    {
        public RentRepository(Database database) : base(database)
        {
        }
    }
}
