﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core
{
    public class EmailSender : INotificationCommand
    {
        public string RecipientAddress { get; set; }
        public string Subject { get; set; }
        public string Text { get; set; }

        public void Execute()
        {
            throw new NotImplementedException();
        }
    }
}
