﻿using System;

namespace LibraryIS.Core.Entities
{
    public class Librarian : Person
    {
        public DateTime? HireDate { get; set; }
    }
}
