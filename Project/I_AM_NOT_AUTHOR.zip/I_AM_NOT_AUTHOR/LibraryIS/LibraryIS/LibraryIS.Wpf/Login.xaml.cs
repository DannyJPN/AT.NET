﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using LibraryIS.Core.Services;
using LibraryIS.Infrastructure;
using LibraryIS.Infrastructure.Repositories;
using LibraryIS.Wpf.Models;
using Unity;
using Unity.Injection;

namespace LibraryIS.Wpf
{
    public partial class Login : Page
    {
        private readonly LibrarianService _librarianService;

        public ObservableCollection<ComboBoxItem> Librarians { get; set; } = new ObservableCollection<ComboBoxItem>();

        public Login()
        {
            _librarianService = App.Container.Resolve<LibrarianService>();
            InitializeComponent();
        }

        protected override void OnInitialized(EventArgs e)
        {
            base.OnInitialized(e);

            _librarianService
                .GetAll()
                .Select(librarian => new LibrarianViewModel(librarian))
                .Select(librarianViewModel => new ComboBoxItem()
                {
                    Content = librarianViewModel.Name,
                    DataContext = librarianViewModel.LibrarianId
                })
                .ToList()
                .ForEach(cbi => Librarians.Add(cbi));


            LibrarianComboBox.ItemsSource = Librarians;
            LibrarianComboBox.SelectedIndex = 0;
            LibrarianComboBox.SelectionChanged += Librarian_Changed;
        }

        private void Librarian_Changed(object sender, SelectionChangedEventArgs e)
        {
            App.Container.Resolve<ApplicationState>().SelectedLibrarianId =
                (LibrarianComboBox.SelectedItem as ComboBoxItem).DataContext as int?;
        }
    }
}
