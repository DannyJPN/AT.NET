﻿namespace LibraryIS.Core.Entities
{
    public class AccessToken : BaseEntity
    {
        public string Token { get; set; }
        public int ReaderId { get; set; }
    }
}
