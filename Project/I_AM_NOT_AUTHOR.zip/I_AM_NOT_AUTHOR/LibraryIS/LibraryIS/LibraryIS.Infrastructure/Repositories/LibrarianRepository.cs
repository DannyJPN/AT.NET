﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class LibrarianRepository : BaseRepository<Librarian>
    {
        public LibrarianRepository(Database database) : base(database)
        {
        }
    }
}
