﻿using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class ReaderRepository : BaseRepository<Reader>
    {
        public ReaderRepository(Database database) : base(database)
        {

        }
    }
}
