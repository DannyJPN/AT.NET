﻿using LibraryIS.Core;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using System.Security.Cryptography;
using System.Text;

namespace LibraryIS.Infrastructure.Repositories
{
    public class BaseRepository<T> : IRepository<T> where T : BaseEntity
    {
        public readonly string TableName = typeof(T).Name;

        private readonly Database _database;

        public BaseRepository(Database database)
        {
            _database = database;
        }

        private List<PropertyInfo> GetEntityProperties(bool includeId = true)
        {
            return typeof(T)
                .GetProperties()
                .Where(p => !p.GetCustomAttributes().Any(a => a is ExcludeAttribute))
                .Where(p => includeId || p.Name != "Id")
                .ToList();
        }

        private Dictionary<string, object> GetEntityPropertyValueDict(T entity, bool includeId = false)
        {
            return entity
                .GetType()
                .GetProperties()
                .Where(p => !p.GetCustomAttributes().Any(a => a is ExcludeAttribute))
                .Where(p => includeId || p.Name != "Id")
                .ToDictionary(p => p.Name, p => p.GetValue(entity));
        }

        private void MapValuesToProperties(T entity, SqlDataReader reader, List<PropertyInfo> properties)
        {
            foreach (PropertyInfo property in properties)
            {
                if (property.PropertyType == typeof(int))
                {
                    property.SetValue(entity, reader.GetInteger(property.Name));
                }
                else if (property.PropertyType == typeof(int?))
                {
                    property.SetValue(entity, reader.GetIntegerOrNull(property.Name));
                }
                else if (property.PropertyType == typeof(string))
                {
                    property.SetValue(entity, reader.GetString(property.Name));
                }
                else if (property.PropertyType == typeof(bool))
                {
                    property.SetValue(entity, reader.GetBoolean(property.Name));
                }
                else if (property.PropertyType == typeof(bool?))
                {
                    property.SetValue(entity, reader.GetBooleanOrNull(property.Name));
                }
                else if (property.PropertyType == typeof(DateTime))
                {
                    property.SetValue(entity, reader.GetDateTime(property.Name));
                }
                else if (property.PropertyType == typeof(DateTime?))
                {
                    property.SetValue(entity, reader.GetDateTimeOrNull(property.Name));
                }
                else if (property.PropertyType == typeof(double))
                {
                    property.SetValue(entity, reader.GetDouble(property.Name));
                }
                else if (property.PropertyType == typeof(double?))
                {
                    property.SetValue(entity, reader.GetDoubleOrNull(property.Name));
                }
            }
        }

        public T GetById(int id)
        {
            _database.Connect();
            string selectByIdSql = $"SELECT * FROM {TableName} WHERE id = @id";
            SqlCommand command = _database.CreateCommand(selectByIdSql);
            command.Parameters.AddWithValue("@id", id);
            SqlDataReader reader = _database.Select(command);
            T entity = (T)Activator.CreateInstance(typeof(T));
            List<PropertyInfo> properties = GetEntityProperties();
            reader.Read();
            try
            {
                MapValuesToProperties(entity, reader, properties);
                _database.CloseConnection();
                return entity;
            }
            catch
            {
                return default(T);
            }
        }

        public List<T> GetAll()
        {
            _database.Connect();
            string selectAllSql = $"SELECT * FROM {TableName}";
            SqlCommand command = _database.CreateCommand(selectAllSql);
            SqlDataReader reader = _database.Select(command);
            List<PropertyInfo> properties = GetEntityProperties();
            List<T> entities = new List<T>();
            while (reader.Read())
            {
                T entity = (T)Activator.CreateInstance(typeof(T));
                MapValuesToProperties(entity, reader, properties);
                entities.Add(entity);
            }

            _database.CloseConnection();
            return entities;
        }

        public void Update(T entity)
        {
            Dictionary<string, object> dict = GetEntityPropertyValueDict(entity);

            _database.Connect();
            StringBuilder updateSqlBuilder = new StringBuilder();
            updateSqlBuilder.Append("UPDATE ");
            updateSqlBuilder.Append(TableName);
            updateSqlBuilder.Append(" SET ");
            bool first = true;
            foreach (string key in dict.Keys)
            {
                if (!first)
                    updateSqlBuilder.Append(", ");
                updateSqlBuilder.Append($"{key}=@{key}");
                first = false;
            }
            updateSqlBuilder.Append(" WHERE id=@id");

            SqlCommand command = _database.CreateCommand(updateSqlBuilder.ToString());
            foreach (string key in dict.Keys)
            {
                command.Parameters.AddWithValue("@" + key, dict[key]);
            }
            command.Parameters.AddWithValue("@id", entity.Id);
            _database.ExecuteNonQuery(command);
            _database.CloseConnection();
        }

        public void Delete(int entityId)
        {
            _database.Connect();
            string deleteSql = $"DELETE FROM {TableName} WHERE id = @id";
            SqlCommand command = _database.CreateCommand(deleteSql);
            command.Parameters.AddWithValue("@id", entityId);
            _database.ExecuteNonQuery(command);
            _database.CloseConnection();
        }

        public int Insert(T entity)
        {
            Dictionary<string, object> dict = GetEntityPropertyValueDict(entity);

            StringBuilder insertSqlBuilder = new StringBuilder();
            insertSqlBuilder.Append("INSERT INTO ");
            insertSqlBuilder.Append(TableName);
            insertSqlBuilder.Append(" (");
            insertSqlBuilder.Append(string.Join(", ", dict.Keys));
            insertSqlBuilder.Append(") VALUES(");
            insertSqlBuilder.Append(string.Join(", ", dict.Keys.Select(k => "@" + k)));
            insertSqlBuilder.Append(") SET @ID = SCOPE_IDENTITY();");

            _database.Connect();
            SqlCommand command = _database.CreateCommand(insertSqlBuilder.ToString());

            foreach (string key in dict.Keys)
            {
                command.Parameters.AddWithValue("@" + key, dict[key]);
            }
            command.Parameters.Add("@Id", SqlDbType.Int, 4).Direction = ParameterDirection.Output;
            _database.ExecuteNonQuery(command);
            int createdEntityId = (int)command.Parameters["@Id"].Value;
            _database.CloseConnection();

            return createdEntityId;
        }
    }
}
