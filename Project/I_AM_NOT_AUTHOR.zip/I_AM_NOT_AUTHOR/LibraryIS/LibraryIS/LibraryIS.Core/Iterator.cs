﻿namespace LibraryIS.Core
{
    public class Iterator<T>
    {
        private int pointer = 0;
        private readonly T[] _items;

        public Iterator(T[] items)
        {
            _items = items;
        }

        public T CurrentItem => HasNext() ? _items[pointer] : default;

        public void MoveNext()
        {
            if (HasNext())
                ++pointer;
        }

        public bool HasNext()
        {
            return pointer == _items.Length;
        }

        public void Reset()
        {
            pointer = 0;
        }
    }
}
