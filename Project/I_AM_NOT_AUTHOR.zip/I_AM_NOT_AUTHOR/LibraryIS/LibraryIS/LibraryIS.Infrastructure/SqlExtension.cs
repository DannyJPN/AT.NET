﻿using System;
using System.Data.SqlClient;

namespace LibraryIS.Infrastructure
{
    public static class SqlExtension
    {
        public static int GetInteger(this SqlDataReader reader, string colName)
        {
            return reader.GetInt32(reader.GetOrdinal(colName));
        }

        public static int? GetIntegerOrNull(this SqlDataReader reader, string colName)
        {
            return reader.IsDBNull(reader.GetOrdinal(colName))
                ? null
                : (int?)reader.GetInt32(reader.GetOrdinal(colName));
        }

        public static bool GetBoolean(this SqlDataReader reader, string colName)
        {
            return reader.GetBoolean(reader.GetOrdinal(colName));
        }

        public static bool? GetBooleanOrNull(this SqlDataReader reader, string colName)
        {
            return reader.IsDBNull(reader.GetOrdinal(colName))
                ? null
                : (bool?)reader.GetBoolean(reader.GetOrdinal(colName));
        }

        public static string GetString(this SqlDataReader reader, string colName)
        {
            return reader.IsDBNull(reader.GetOrdinal(colName))
                ? null
                : reader.GetString(reader.GetOrdinal(colName));
        }

        public static DateTime GetDateTime(this SqlDataReader reader, string colName)
        {
            return reader.GetDateTime(reader.GetOrdinal(colName));
        }

        public static DateTime? GetDateTimeOrNull(this SqlDataReader reader, string colName)
        {
            return reader.IsDBNull(reader.GetOrdinal(colName))
                ? null
                : (DateTime?)reader.GetDateTime(reader.GetOrdinal(colName));
        }

        public static double GetDouble(this SqlDataReader reader, string colName)
        {
            return reader.GetFloat(reader.GetOrdinal(colName));
        }

        public static double? GetDoubleOrNull(this SqlDataReader reader, string colName)
        {
            return reader.IsDBNull(reader.GetOrdinal(colName))
                ? null
                : (double?)reader.GetFloat(reader.GetOrdinal(colName));
        }
    }
}
