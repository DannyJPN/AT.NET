﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class ReaderService : BaseService<Reader>
    {
        private readonly IRepository<Rent> _rentRepository;
        private readonly IRepository<Reservation> _reservationRepository;
        private readonly IRepository<AccessToken> _accessTokenRepository;
        private readonly RentService _rentService;
        private readonly AccessTokenService _accessTokenService;

        public ReaderService(
            IRepository<Reader> repository,
            IRepository<Rent> rentRepository,
            IRepository<Reservation> reservationRepository,
            IRepository<AccessToken> accessTokenRepository,
            RentService rentService,
            AccessTokenService accessTokenService

        ) : base(repository)
        {
            _rentRepository = rentRepository;
            _reservationRepository = reservationRepository;
            _accessTokenRepository = accessTokenRepository;
            _rentService = rentService;
            _accessTokenService = accessTokenService;
        }

        public override Reader GetById(int id)
        {
            Reader reader = base.GetById(id);
            reader.LazyReservations = new Lazy<List<Reservation>>(() =>
        {
            return _reservationRepository
                .GetAll()
                .Where(r => r.ReaderId == id)
                .ToList();
        });

            reader.LazyRents = new Lazy<List<Rent>>(() =>
            {
                return _rentService
                    .GetAll()
                    .Where(r => r.ReaderId == id)
                    .ToList();
            });

            reader.LazyAccessToken = new Lazy<AccessToken>(() =>
            {
                return _accessTokenRepository
                    .GetAll()
                    .FirstOrDefault(r => r.ReaderId == id);
            });

            return reader;
        }

        public override List<Reader> GetAll()
        {
            List<Reader> readers = base.GetAll();
            readers.ForEach(reader =>
            {
                reader.LazyReservations = new Lazy<List<Reservation>>(() =>
                {
                    return _reservationRepository
                        .GetAll()
                        .Where(r => r.ReaderId == reader.Id)
                        .ToList();
                });

                reader.LazyRents = new Lazy<List<Rent>>(() =>
                {
                    return _rentService
                        .GetAll()
                        .Where(r => r.ReaderId == reader.Id)
                        .ToList();
                });

                reader.LazyAccessToken = new Lazy<AccessToken>(() =>
                {
                    return _accessTokenRepository
                        .GetAll()
                        .FirstOrDefault(r => r.ReaderId == reader.Id);
                });
            });

            return readers;
        }

        public List<Book> GetRentedBooks(int readerId)
        {
            return _rentRepository
                .GetAll()
                .Where(r => r.ReaderId == readerId && !r.Returned)
                .Select(r => r.Book)
                .Distinct()
                .ToList();
        }

        public bool IsAlreadyRegistered(int identificationDocumentNumber)
        {
            return _selfRepository
                   .GetAll()
                   .FirstOrDefault(r => r.IdentificationDocumentNumber == identificationDocumentNumber) == null;
        }

        public void Logout(int readerId)
        {
            _accessTokenService
                .GetAll()
                .Where(accessToken => accessToken.ReaderId == readerId)
                .ToList()
                .ForEach(accessToken => _accessTokenService.Delete(accessToken.Id));
        }

        public AccessToken Login(string login, string password)
        {
            if (_selfRepository.GetAll().Any(r => r.Login == login && r.Password == password))
            {
                Reader reader = _selfRepository.GetAll().First(r => r.Login == login && r.Password == password);
                AccessToken accessToken = _accessTokenService.GenerateToken(reader.Id);
                _accessTokenRepository.Insert(accessToken);
                return accessToken;
            }

            return null;
        }

        public void Register(Reader reader)
        {
            if (!IsAlreadyRegistered(reader.IdentificationDocumentNumber))
            {
                Insert(reader);
            }
            else
            {
                throw new Exception("Reader with identification document number is already registered.");
            }
        }
    }
}
