﻿using System;
using System.Collections.Generic;

namespace LibraryIS.Core.Entities
{
    public class Book : BaseEntity
    {
        public string ISBN { get; set; }
        public string Name { get; set; }
        public string Description { get; set; }
        public DateTime? PublicationDate { get; set; }
        public DateTime? CreatedDate { get; set; }
        public int GenreId { get; set; }

        [Exclude]
        public Genre Genre => LazyGenre.Value;

        [Exclude]
        public Lazy<Genre> LazyGenre { private get; set; } = new Lazy<Genre>(() => throw new NotImplementedException());

        [Exclude]
        public List<Author> Authors => LazyAuthors.Value;

        [Exclude]
        public Lazy<List<Author>> LazyAuthors { private get; set; } = new Lazy<List<Author>>(() => throw new NotImplementedException());
    }
}
