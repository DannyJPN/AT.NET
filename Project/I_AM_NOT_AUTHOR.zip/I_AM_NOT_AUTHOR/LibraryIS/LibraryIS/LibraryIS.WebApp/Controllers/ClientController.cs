﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Enums;
using LibraryIS.Core.Models;
using LibraryIS.Core.Services;
using LibraryIS.WebApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace LibraryIS.WebApp.Controllers
{
    [Authorize]
    public class ClientController : Controller
    {
        private readonly BookService _bookService;
        private readonly GenreService _genreService;
        private readonly ReaderService _readerService;
        private readonly RentService _rentService;
        private readonly ReservationService _reservationService;

        public ClientController(
            BookService bookService,
            GenreService genreService,
            ReaderService readerService,
            RentService rentService,
            ReservationService reservationService
        )
        {
            _bookService = bookService;
            _genreService = genreService;
            _readerService = readerService;
            _rentService = rentService;
            _reservationService = reservationService;
        }

        [HttpGet]
        public IActionResult BorrowedBooks()
        {
            //TODO: autetication
            int readerId = 1;
            ViewBag.Reader = _readerService.GetById(readerId);
            return View();
        }

        [HttpPost]
        public IActionResult BorrowedBooks([FromForm] ExtendReturnDayForm extendReturnDayForm)
        {
            int days = 7;
            switch (extendReturnDayForm.ExtendRange)
            {
                case ExtendRangeEnum.D4:
                    days = 4;
                    break;

                case ExtendRangeEnum.W1:
                    days = 7;
                    break;

                case ExtendRangeEnum.W2:
                    days = 14;
                    break;

                case ExtendRangeEnum.M1:
                    days = 31;
                    break;
            }

            ViewBag.ExtendSuccessful = _rentService.ExtendReturnDate(extendReturnDayForm.RentId, days);
            ModelState.Clear();
            return BorrowedBooks();
        }

        [HttpGet]
        public IActionResult BrowseBooks()
        {
            ViewBag.Genres = _genreService.GetAll();

            return View();
        }

        [HttpPost]
        public IActionResult BrowseBooks([FromForm] BookFilter filter)
        {
            ViewBag.Books = _bookService.Filter(filter);

            return BrowseBooks();
        }

        [HttpGet]
        public IActionResult DetailBook([FromQuery] int bookId)
        {
            ViewBag.Book = _bookService.GetById(bookId);
            if (ViewBag.Book == null)
            {
                return NotFound();
            }

            return View();
        }

        [HttpPost]
        public IActionResult DetailBook([FromForm] ReservationForm reservationForm)
        {
            ViewBag.ReservationSuccessful = _reservationService.CreateReservation(reservationForm.BookId, reservationForm.ReservationDate);
            return DetailBook(reservationForm.BookId);
        }

        [HttpGet]
        public ViewResult DataGrid([FromQuery] int bookId = 0)
        {
            ModelState.Remove("bookId");

            ViewBag.Books = _bookService.GetAll();
            if (bookId != 0)
            {
                Book book = _bookService.GetById(bookId);
                ViewBag.Book = book;
                CultureInfo usCultureInfo = new CultureInfo("en-US", false);

                return View(new DataGridForm()
                {
                    ISBN = book.ISBN,
                    Name = book.Name,
                    PublicationDate = book.PublicationDate.Value.ToString("d", usCultureInfo)
                });
            }

            return View();
        }

        [HttpPost]
        public ViewResult DataGrid([FromForm] DataGridForm form)
        {
            if (ModelState.IsValid)
            {
                if (form.BookId != null && form.BookId != 0)
                {
                    Book book = _bookService.GetById(form.BookId.Value);
                    book.ISBN = form.ISBN;
                    book.Name = form.Name;
                    book.PublicationDate = DateTime.Parse(form.PublicationDate);

                    _bookService.Update(book);
                }
                else
                {
                    _bookService.Insert(new Book()
                    {
                        ISBN = form.ISBN,
                        Name = form.Name,
                        PublicationDate = DateTime.Parse(form.PublicationDate),
                        Description = "",
                        GenreId = 1,
                        CreatedDate = DateTime.Now
                    });
                }
            }
            else
            {
                return DataGrid(form.BookId.Value);
            }

            return DataGrid();
        }

        [HttpPost]
        public IActionResult DeleteBook([FromForm] int bookId)
        {
            _bookService.Delete(bookId);
            return RedirectToAction("DataGrid");
        }
    }
}