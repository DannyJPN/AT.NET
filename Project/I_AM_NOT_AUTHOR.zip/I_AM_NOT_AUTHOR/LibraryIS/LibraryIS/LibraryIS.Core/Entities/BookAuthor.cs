﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Core.Entities
{
    public class BookAuthor : BaseEntity
    {
        public int BookId { get; set; }
        public int AuthorId { get; set; }
    }
}
