﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryIS.WebApp.Models
{
    public class DataGridForm
    {
        [Required]
        public int? BookId { get; set; } = 0;

        [Required(ErrorMessage = "ISBN is required field")]
        public string ISBN { get; set; }

        [Required(ErrorMessage = "Name is required field")]
        public string Name { get; set; }

        [DateValidation(ErrorMessage = "Please enter US date format")]
        [Required(ErrorMessage = "Publication Date is required field")]

        public string PublicationDate { get; set; }
    }
}
