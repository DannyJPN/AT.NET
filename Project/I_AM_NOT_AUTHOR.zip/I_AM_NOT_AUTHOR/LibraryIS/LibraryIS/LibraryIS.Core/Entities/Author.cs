﻿using System;

namespace LibraryIS.Core.Entities
{
    public class Author : BaseEntity
    {
        public string Name { get; set; }
        public DateTime? BirthDate { get; set; }
    }
}
