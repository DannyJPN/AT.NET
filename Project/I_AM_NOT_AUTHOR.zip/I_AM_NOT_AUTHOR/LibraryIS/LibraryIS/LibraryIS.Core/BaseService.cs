﻿using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;
using System.Collections.Generic;

namespace LibraryIS.Core
{
    public abstract class BaseService<T> where T : BaseEntity
    {
        protected readonly IRepository<T> _selfRepository;

        protected BaseService(IRepository<T> repository)
        {
            _selfRepository = repository;
        }

        public virtual T GetById(int id)
        {
            return _selfRepository.GetById(id);
        }

        public virtual List<T> GetAll()
        {
            return _selfRepository.GetAll();
        }

        public void Update(T entity)
        {
            _selfRepository.Update(entity);
        }

        public void Delete(int entityId)
        {
            _selfRepository.Delete(entityId);
        }

        public T Insert(T entity)
        {
            int id = _selfRepository.Insert(entity);
            return GetById(id);
        }
    }
}
