﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class AccessTokenRepository : BaseRepository<AccessToken>
    {
        public AccessTokenRepository(Database database) : base(database)
        {
        }
    }
}
