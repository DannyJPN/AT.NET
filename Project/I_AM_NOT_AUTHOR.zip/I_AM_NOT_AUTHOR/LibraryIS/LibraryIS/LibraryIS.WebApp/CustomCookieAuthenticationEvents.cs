﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using LibraryIS.Core.Services;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace LibraryIS.WebApp
{
    public class CustomCookieAuthenticationEvents : CookieAuthenticationEvents
    {
        private readonly AccessTokenService _accessTokenService;

        public CustomCookieAuthenticationEvents(AccessTokenService accessTokenService)
        {
            _accessTokenService = accessTokenService;
        }

        public override async Task ValidatePrincipal(CookieValidatePrincipalContext context)
        { 
            var userPrincipal = context.Principal;

            try
            {
                string token = userPrincipal.Claims.First(c => c.Type == "Token").Value;
                if (_accessTokenService.GetAll().All(accessToken => accessToken.Token != token))
                {
                    context.RejectPrincipal();
                    await context.HttpContext.SignOutAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme);
                }
            }
            catch (Exception e)
            {
                context.RejectPrincipal();
                await context.HttpContext.SignOutAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme);
            }
        }
    }
}
