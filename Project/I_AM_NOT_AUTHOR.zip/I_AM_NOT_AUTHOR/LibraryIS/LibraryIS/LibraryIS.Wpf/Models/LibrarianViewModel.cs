﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Wpf.Models
{
    public class LibrarianViewModel
    {
        public int LibrarianId { get; set; }
        public string Name { get; set; }

        public LibrarianViewModel(Librarian librarian)
        {
            LibrarianId = librarian.Id;
            Name = librarian.FirstName + " " + librarian.LastName;
        }
    }
}
