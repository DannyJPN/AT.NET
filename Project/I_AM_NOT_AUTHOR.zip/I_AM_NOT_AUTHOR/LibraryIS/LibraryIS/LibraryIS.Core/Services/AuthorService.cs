﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class AuthorService : BaseService<Author>
    {
        public AuthorService(IRepository<Author> repository) : base(repository)
        {
        }
    }
}
