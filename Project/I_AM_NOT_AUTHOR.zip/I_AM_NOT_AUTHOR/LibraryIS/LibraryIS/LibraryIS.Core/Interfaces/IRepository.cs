﻿using LibraryIS.Core.Entities;
using System.Collections.Generic;

namespace LibraryIS.Core.Interfaces
{
    public interface IRepository<T> where T : BaseEntity
    {
        T GetById(int id);
        List<T> GetAll();
        void Update(T entity);
        void Delete(int entityId);
        int Insert(T entity);
    }
}
