﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LibraryIS.Wpf
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            
        }

        private void Select_Login_View(object sender, RoutedEventArgs e)
        {
            ViewFrame.Source = new Uri("Login.xaml", UriKind.Relative);
        }

        private void Select_Create_Rent_View(object sender, RoutedEventArgs e)
        {
            ViewFrame.Source = new Uri("CreateRent.xaml", UriKind.Relative);
        }

        private void Select_Register_Reader_View(object sender, RoutedEventArgs e)
        {
            ViewFrame.Source = new Uri("RegisterReader.xaml", UriKind.Relative);
        }

        private void Select_Add_Book_View(object sender, RoutedEventArgs e)
        {
            ViewFrame.Source = new Uri("AddBook.xaml", UriKind.Relative);
        }
    }
}
