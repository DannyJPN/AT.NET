﻿namespace LibraryIS.Core.Entities
{
    public abstract class BaseEntity
    {
        public int Id { get; set; }
    }
}
