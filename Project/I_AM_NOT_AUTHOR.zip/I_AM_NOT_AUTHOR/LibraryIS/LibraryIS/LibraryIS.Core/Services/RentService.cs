﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class RentService : BaseService<Rent>
    {
        private readonly IRepository<Reservation> _reservationRepository;
        private readonly BookService _bookService;

        public RentService(
            IRepository<Rent> repository,
            IRepository<Reservation> reservationRepository,
            BookService bookService
        ) : base(repository)
        {
            _reservationRepository = reservationRepository;
            _bookService = bookService;
        }

        public override Rent GetById(int id)
        {
            Rent rent = base.GetById(id);
            rent.LazyBook = new Lazy<Book>(() =>
            {
                return _bookService
                        .GetById(id);
            });

            return rent;
        }

        public override List<Rent> GetAll()
        {
            List<Rent> rents = base.GetAll();
            rents.ForEach(rent =>
            {
                rent.LazyBook = new Lazy<Book>(() =>
                {
                    return _bookService
                            .GetById(rent.BookId);
                });
            });

            return rents;
        }

        public bool ExtendReturnDate(int rentId, int days = 7)
        {
            Rent rent = GetById(rentId);
            DateTime to = rent.ReturnDate.AddDays(days);

            if (to < DateTime.Now || to > DateTime.Now.AddMonths(3))
                return false;

            IEnumerable<Reservation> overlappingReservations = _reservationRepository
                .GetAll()
                .Where(r => rentId == r.BookId && r.ReservationDate < to)
                .ToList();

            //someone else has already reservation on book from rent list
            if (overlappingReservations.Any())
                return false;

            //extend return date...
            rent.ReturnDate = to;
            Update(rent);
            return true;
        }

        /*
        public Iterator<Book> GetBookIteratorForRent(int rentId)
        {
            return new Iterator<Book>(_selfRepository.GetById(rentId).Books.ToArray());
        }
        */
    }
}
