﻿using System;
using System.Collections.Generic;

namespace LibraryIS.Core.Entities
{
    public class Rent : BaseEntity
    {
        public DateTime CreatedDate { get; set; }
        public DateTime ReturnDate { get; set; }
        public int ReaderId { get; set; }
        public int LibrarianId { get; set; }
        public bool Returned { get; set; } = false;
        public int BookId { get; set; }

        [Exclude]
        public Book Book => LazyBook.Value;

        [Exclude]
        public Lazy<Book> LazyBook { private get; set; } = new Lazy<Book>(() => throw new NotImplementedException());
    }
}
