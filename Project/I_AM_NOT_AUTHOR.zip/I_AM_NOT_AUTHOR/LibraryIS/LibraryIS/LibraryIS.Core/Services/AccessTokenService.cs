﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class AccessTokenService : BaseService<AccessToken>
    {
        public AccessTokenService(IRepository<AccessToken> repository) : base(repository)
        {
        }

        public AccessToken GenerateToken(int readerId)
        {
            Random rand = new Random();
            string token = string.Empty;
            for (int i = 0; i < 10; i++)
            {
                token += (char)(65 + rand.Next() % 40);
            }

            return new AccessToken()
            {
                ReaderId = readerId,
                Token = token
            };
        }
    }
}
