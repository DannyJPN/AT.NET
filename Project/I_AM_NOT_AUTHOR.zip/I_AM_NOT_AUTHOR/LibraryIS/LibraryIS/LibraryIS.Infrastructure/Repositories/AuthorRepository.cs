﻿using System;
using System.Collections.Generic;
using System.Text;
using LibraryIS.Core.Entities;

namespace LibraryIS.Infrastructure.Repositories
{
    public class AuthorRepository : BaseRepository<Author>
    {
        public AuthorRepository(Database database) : base(database)
        {
        }
    }
}
