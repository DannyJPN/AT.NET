﻿using LibraryIS.Core.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace LibraryIS.Infrastructure.Repositories
{
    public class BookAuthorRepository : BaseRepository<BookAuthor>
    {
        public BookAuthorRepository(Database database) : base(database)
        {
        }
    }
}
