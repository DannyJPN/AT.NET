﻿using LibraryIS.Core.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LibraryIS.WebApp.Models
{
    public class ExtendReturnDayForm
    {
        public int RentId { get; set; }
        public ExtendRangeEnum ExtendRange { get; set; }
    }
}
