﻿using System;

namespace LibraryIS.Core
{
    public class ExcludeAttribute : Attribute
    {
    }
}