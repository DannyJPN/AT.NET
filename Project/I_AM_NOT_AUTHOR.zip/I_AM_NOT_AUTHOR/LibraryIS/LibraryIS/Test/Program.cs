﻿using System;
using System.Collections.Generic;
using LibraryIS.Core.Entities;
using LibraryIS.Infrastructure;
using LibraryIS.Infrastructure.Repositories;

namespace Test
{
    public class Program
    {
        static void Main(string[] args)
        {
            Database database = new Database("server=localhost;database=LibraryIS;Trusted_Connection=True;");


            GenreRepository genreRepository = new GenreRepository(database);
            genreRepository.Insert(new Genre()
            {
                Name = "Pěkné knihy"
            });

            genreRepository.Insert(new Genre()
            {
                Name = "Fajné knihy"
            });

            genreRepository.Insert(new Genre()
            {
                Name = "Poučné knihy"
            });

            genreRepository.Insert(new Genre()
            {
                Name = "Nějaké knihy"
            });

            BookRepository bookRepository = new BookRepository(database);
            bookRepository.Insert(new Book()
            {
                CreatedDate = DateTime.Now,
                Description = "The UML appeared in 1997 to eliminate the bedlam that had overtaken graphical modeling languages in the object-oriented world. Before the UML there were a host of such languages, differing in all sorts of annoying ways. Now the UML is pretty much the only game in town, which makes life much simpler for many people involved in OO software development",
                GenreId = 3,
                ISBN = "9788024720623",
                Name = "UML Distilled",
                PublicationDate = DateTime.Now
            });

            bookRepository.Insert(new Book()
            {
                CreatedDate = DateTime.Now,
                Description = "Written in 1920, premiered in Prague in 1921, and first performed in New York in 1922—garnered worldwide acclaim for its author and popularized the word robot. Mass-produced as efficient laborers to serve man, Capek’s Robots are an android product—they remember everything but think of nothing new. But the Utopian life they provide ultimately lacks meaning, and the humans they serve stop reproducing. When the Robots revolt, killing all but one of their masters, they must strain to learn the secret of self-duplication. It is not until two Robots fall in love and are christened “Adam” and “Eve” by the last surviving human that Nature emerges triumphant.",
                GenreId = 2,
                ISBN = "9788075461636",
                Name = "R.U.R.",
                PublicationDate = DateTime.Now,
            });

            bookRepository.Insert(new Book()
            {
                CreatedDate = DateTime.Now,
                Description = "whatever",
                GenreId = 1,
                ISBN = "978802472546523",
                Name = "Oliver Twist",
                PublicationDate = DateTime.Now
            });

            AuthorRepository authorRepository = new AuthorRepository(database);
            authorRepository.Insert(new Author()
            {
                Name = "Martin Fowler",
                BirthDate = new DateTime(1963, 1, 1)
            });

            authorRepository.Insert(new Author()
            {
                Name = "Karel Čapek",
                BirthDate = new DateTime(1890, 1, 9)
            });

            BookAuthorRepository bookAuthorRepository = new BookAuthorRepository(database);
            bookAuthorRepository.Insert(new BookAuthor()
            {
                AuthorId = 1,
                BookId = 1,
            });

            bookAuthorRepository.Insert(new BookAuthor()
            {
                AuthorId = 2,
                BookId = 2,
            });

            bookAuthorRepository.Insert(new BookAuthor()
            {
                AuthorId = 1,
                BookId = 3,
            });

            bookAuthorRepository.Insert(new BookAuthor()
            {
                AuthorId = 2,
                BookId = 3,
            });

            ReaderRepository readerRepository = new ReaderRepository(database);
            readerRepository.Insert(new Reader()
            {
                FirstName = "Dominik",
                LastName = "Stacha",
                IdentificationDocumentNumber = 123456798,
                IsStudent = true,
                Login = "STA0474",
                Password = "ahoj",
                RegistrationDate = DateTime.Now,
                BirthDate = DateTime.Now,
                PhoneNumber = 792_363_305,
                Email = "dominik.stacha@gmail.com"
            });

            LibrarianRepository librarianRepository = new LibrarianRepository(database);
            librarianRepository.Insert(new Librarian()
            {
                BirthDate = DateTime.Now,
                FirstName = "Tereza",
                LastName = "Škutová",
                HireDate = DateTime.Now
            });

            librarianRepository.Insert(new Librarian()
            {
                BirthDate = DateTime.Now,
                FirstName = "Lukáš",
                LastName = "Bik",
                HireDate = DateTime.Now
            });

            librarianRepository.Insert(new Librarian()
            {
                BirthDate = DateTime.Now,
                FirstName = "Jakub",
                LastName = "Plesník",
                HireDate = DateTime.Now
            });

            ReservationRepository reservationRepository = new ReservationRepository(database);
            reservationRepository.Insert(new Reservation()
            {
                BookId = 1,
                Note = "whatever",
                ReaderId = 1,
                ReservationDate = DateTime.Now.AddDays(32)
            });

            RentRepository rentRepository = new RentRepository(database);
            rentRepository.Insert(new Rent()
            {
                CreatedDate = DateTime.Now,
                LibrarianId = 1,
                ReaderId = 1,
                ReturnDate = DateTime.Now.AddDays(30),
                BookId = 1
            });

            rentRepository.Insert(new Rent()
            {
                CreatedDate = DateTime.Now,
                LibrarianId = 1,
                ReaderId = 1,
                ReturnDate = DateTime.Now.AddDays(30),
                BookId = 2
            });


            /*
            ReservationRepository reservationRepository = new ReservationRepository(database);
            reservationRepository.Insert(new Reservation()
            {
                BookId = 1,
                Note = "whatever",
                ReaderId = 1,
                ReservationDate = DateTime.Now
            });
            */



            /*
            Reader whatever = readerRepository.GetById(6);
            whatever.FirstName = "Lukáš";
            whatever.LastName = "Bik";
            readerRepository.Update(whatever);
            */

            //readerRepository.Delete(4);

        }
    }
}
