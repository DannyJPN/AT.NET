﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LibraryIS.Core.Entities;
using LibraryIS.Core.Interfaces;

namespace LibraryIS.Core.Services
{
    public class ReservationService : BaseService<Reservation>
    {
        private readonly IRepository<Book> _bookRepository;
        private readonly IRepository<Reader> _readerRepository;
        private readonly IRepository<Rent> _rentRepository;

        public ReservationService(
            IRepository<Reservation> repository,
            IRepository<Book> bookRepository,
            IRepository<Reader> readerRepository,
            IRepository<Rent> rentRepository
        ) : base(repository)
        {
            _bookRepository = bookRepository;
            _readerRepository = readerRepository;
            _rentRepository = rentRepository;
        }

        public override Reservation GetById(int id)
        {
            Reservation reservation = base.GetById(id);

            reservation.LazyBook = new Lazy<Book>(() =>
            {
                return _bookRepository.GetById(reservation.BookId);
            });

            reservation.LazyReader = new Lazy<Reader>(() =>
            {
                return _readerRepository.GetById(reservation.ReaderId);
            });

            return reservation;
        }

        public override List<Reservation> GetAll()
        {
            List<Reservation> reaservations = base.GetAll();
            reaservations.ForEach(reservation =>
            {
                reservation.LazyBook = new Lazy<Book>(() =>
                {
                    return _bookRepository.GetById(reservation.BookId);
                });

                reservation.LazyReader = new Lazy<Reader>(() =>
                {
                    return _readerRepository.GetById(reservation.ReaderId);
                });
            });

            return reaservations;
        }

        public bool CreateReservation(int bookId, DateTime reservationDate)
        {
            if(reservationDate < DateTime.Now)
            {
                return false;
            }

            //check rents
            IEnumerable<Rent> overlappingRents = _rentRepository
                    .GetAll()
                    .Where(r => r.CreatedDate < reservationDate && r.ReturnDate > reservationDate && r.BookId == bookId);

            if (overlappingRents.Any())
                return false;

            //check reservations
            IEnumerable<Reservation> overlappingReservations = _selfRepository
                    .GetAll()
                    .Where(r => r.BookId == bookId && r.ReservationDate.Value.AddMonths(1) > reservationDate); //reservations + 1 month

            if (overlappingReservations.Any())
                return false;

            _selfRepository.Insert(new Reservation()
            {
                BookId = bookId,
                ReaderId = 1, //TODO: authentication
                Note = "whatever",
                ReservationDate = reservationDate
            });

            return true;
        }
    }
}
